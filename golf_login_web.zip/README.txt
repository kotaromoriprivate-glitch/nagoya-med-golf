名大医学部ゴルフ部 Safariログイン接続テスト

1. GitHubの nagoya-med-golf リポジトリでルートの index.html をこのファイルに置き換える。
2. Commit changes を押す。Pagesのデプロイ完了後にSafariで既存のPages URLを開く。
3. Supabase Authenticationで作成したテスト用メールアドレスとパスワードでログインする。
4. membersテーブルに紐づけた「テスト会計係」が表示されることを確認する。

注意:
- これはメール+パスワードでの接続試験版。学籍番号ログイン、報告、配車、Excel出力は未実装。
- Supabase URLとpublishable keyは公開用。secret/service_role keyは絶対にHTMLやGitHubに入れない。
- RLSが有効であることを維持する。
- テスト用の認証情報や個人情報をGitHubへアップロードしない。
- 現在のPublicリポジトリのコミット履歴に秘密情報がないか確認する。
